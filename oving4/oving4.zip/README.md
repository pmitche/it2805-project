it2805-project
==============

IT2805 Web Technologies project - making a ten-page website with HTML, CSS, JavaScript ++
